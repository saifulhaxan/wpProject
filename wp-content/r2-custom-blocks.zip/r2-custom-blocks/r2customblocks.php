<?php
/*
Plugin Name: R2 Custom Blocks
Plugin URI:
Description: R2 Theme Custom Blocks
Version: 1.0.0
Author: Biggiant Pk
Author URI: https://www.fiverr.com/biggiantpk
*/
function r2_register_acf_block_types() {

    /*
    ** HomePage First Block
    */
    register_block_type( __DIR__ . '/blocks/search-block/block.json' );

    /*
    ** Posts Filters Block
    */
    register_block_type( __DIR__ . '/blocks/posts-filter-block/block.json' );

    /*
    ** Posts Filters Block
    */
    register_block_type( __DIR__ . '/blocks/trending-articles-block/block.json' );
   
    /*
    ** Posts Video Block
    */
    register_block_type( __DIR__ . '/blocks/post-video-block/block.json' );

    /*
    ** Featured Article Block
    */
    register_block_type( __DIR__ . '/blocks/featured-article-block/block.json' );
    
    /*
    ** Featured Article Block
    */
    register_block_type( __DIR__ . '/blocks/faqs-block/block.json' );
}   

if ( function_exists( 'acf_register_block_type' ) ) {
    add_action( 'acf/init', 'r2_register_acf_block_types' );
}

/*
** Enqueue scripts
*/
function plugin_enqueue_scripts() {
    //wp_enqueue_script( 'vanilla-lazyload', get_template_directory_uri() . '/assets/components/dist/vanilla-lazyload/vanilla-lazyload.min.js', array(), '17.1.2', true );
   // conditionals for block(s) on page or page types

	if ( has_block( 'acf/carousel' ) && !is_admin() ) {
       wp_enqueue_script( 'ts-carousel', plugin_dir_url( __FILE__ ) . '/blocks/carousel/carousel.js', array(), '', true );
	}
}
add_action('wp_enqueue_scripts', 'plugin_enqueue_scripts');
