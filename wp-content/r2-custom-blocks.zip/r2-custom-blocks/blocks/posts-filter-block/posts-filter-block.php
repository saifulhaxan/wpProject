<?php

/**
 * Posts Filter Block Template.
 *
 * @param   array $block The block settings and attributes.
 * @param   string $content The block inner HTML (empty).
 * @param   bool $is_preview True during AJAX preview.
 * @param   (int|string) $post_id The post ID this block is saved to.
 */

// Create id attribute allowing for custom "anchor" value.
?>
<section class="second-one">
      <div class="container is-fluid bg-silver">
        <div class="container is-fullhd">
          <div class="columns is-mobile">
            <div class="column is-full">
              <div class="tabs of-categories">
                <ul>
                  <li class="is-active"><a>All</a></li>
                  <li><a>Digital</a></li>
                  <li><a>Growth</a></li>
                  <li><a>Influencer</a></li>
                  <li><a>Marketing</a></li>
                  <li><a>Tech</a></li>
                  <li><a>Performance</a></li>
                  <li><a>Videos</a></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
      <article class="container is-fullhd v-pad is-top-featured-post">
        <div class="columns is-mobile">
          <div class="column full is-flex is-flex-direction-row">
            <div class="b-author is-flex-direction-row is-align-content-center margin-right-80 m40">
              <div class="author-img">
                <img src="img/marina-doe.png" alt="marina doe">
              </div>
              <div class="author-detail">
                <p class="text-md">
                  Author
                </p>
                <p class="text-xl is-wght-700">
                  Marina Doe
                </p>
              </div>

            </div>
            <div class="b-published-date margin-right-80 m40">
              <p class="text-md">
                Published
              </p>
              <p class="text-xl is-wght-700">
                Oct 20, 2022
              </p>
            </div>
            <div class="b-comments margin-right-80 m40">
              <p class="text-md">
                No Comments
              </p>
              <p class="text-xl is-wght-700">
                Start a Conversation
              </p>
            </div>
          </div>
        </div>
        <div class="columns is-mobile">
          <div class="column full is-flex is-flex-direction-row">
            <a href="#" class="custom tag is-rounded is-transparent is-border-red text-sm">Marketing</a>
            <a href="#" class="custom tag is-rounded is-transparent is-border-red text-sm">Performance</a>
          </div>
        </div>
        <div class="columns is-mobile">
          <div class="column full">
            <div class="is-flex is-flex-direction-row is-mobile direction-column-reverse">
              <div class="is-flex is-flex-direction-column">
                <h3>Google Ads to Reddit: How We Tested 7 Different Acquisition Channels to Get Better Performance</h3>
                <p class="text-xl v-margin-30 color-grey">Phasellus at iaculis nisl. Vivamus eleifend purus quis elit suscipit dictum. Cras vitae sapien sed risus molestie lobortis. Mauris fermentum vulputate interdum. Quisque et turpis ullamcorper leo tristique mollis. Duis ut consequat justo, in mollis ligula.</p>
                <a href="#" class="button button-article">Read the article <img src="img/right-arrow.svg" alt=""></a>
              </div>
                <img src="img/top-featured-img.png" alt="first-featured-img">
            </div>
          </div>
        </div>
     
            <h6 class="recent-articles">Articles from the last two weeks</h6>
            <div class="multiple-posts-slides">
              <div class="recent-post-slides">
              <div class="is-flex is-flex-direction-row">
                <div class="b-author is-flex-direction-row is-align-content-center margin-right-80">
                  <div class="author-img">
                    <img src="img/john-tailver.png" width="120" alt="marina doe">
                  </div>
                  <div class="author-detail is-flex is-flex-direction-column-reverse">
                    <p class="text-md">
                      John Toliver
                    </p>
                    <h6 class="is-wght-600">
                      Performance Branding: A Paradigm Shift in Marketing Strategies
                    </h6>
                  </div>
    
                </div>
              </div>
            </div>
              <div class="recent-post-slides">
              <div class="is-flex is-flex-direction-row">
                <div class="b-author is-flex-direction-row is-align-content-center margin-right-80">
                  <div class="author-img">
                    <img src="img/lucille-matney.png" width="120" alt="marina doe">
                  </div>
                  <div class="author-detail is-flex is-flex-direction-column-reverse">
                    <p class="text-md">
                      Lucille Matney
                    </p>
                    <h6 class="is-wght-600">
                      Klarna’s Marketing Strategy: The Unique Growth Story Behind The Brand
                    </h6>
                  </div>
    
                </div>
              </div>
            </div>
              <div class="recent-post-slides">
              <div class="is-flex is-flex-direction-row">
                <div class="b-author is-flex-direction-row is-align-content-center margin-right-80">
                  <div class="author-img">
                    <img src="img/erine-philips.png" width="120" alt="marina doe">
                  </div>
                  <div class="author-detail is-flex is-flex-direction-column-reverse">
                    <p class="text-md">
                      Erline Phillips
                    </p>
                    <h6 class="is-wght-600">
                      Data Science in Marketing: A Comprehensive Guide (With Examples)
                    </h6>
                  </div>
    
                </div>
              </div>
            </div>
            </div>
      </article>

    </section>