<?php

/**
 * Featured Article Block Template.
 *
 * @param   array $block The block settings and attributes.
 * @param   string $content The block inner HTML (empty).
 * @param   bool $is_preview True during AJAX preview.
 * @param   (int|string) $post_id The post ID this block is saved to.
 */

// Create id attribute allowing for custom "anchor" value.
?>
<section class="fifth-one">
      <div class="container is-fullhd">
        <h3 class="customized-title">Featured Articles</h3>
        <div class="columns is-multiline is-mobile">
          <div class="column is-full-mobile is-half-desktop is-half-widescreen is-half-fullhd">
            <img src="img/feautered-article.png" alt="" srcset="" class="full-width">
          </div>
          <div class="column is-full-mobile is-half-desktop is-half-widescreen is-half-fullhd">
            <article class="tile transparent-invert-black is-flex-direction-column">
              <div class="is-flex is-flex-direction-row is-justify-content-space-between">
                  <div class="category-tags">
                    <a href="#" class="custom tag is-rounded is-border-red is-transparent text-sm">Marketing</a>
                    <a href="#" class="custom tag is-rounded is-border-red is-transparent text-sm">Performance</a>
                  </div>
            </div>
              <div class="content">
               <h4>Google Ads to Reddit: How We Tested 7 Different Acquisition Channels to Get Better Performance</h4>
               <p>Phasellus at iaculis nisl. Vivamus eleifend purus quis elit suscipit dictum. Cras vitae sapien sed risus molestie lobortis. Mauris fermentum vulputate interdum. Quisque et turpis ullamcorper leo tristique mollis. Duis ut consequat justo, in mollis ligula.</p>
              </div>
              <div class="b-author is-flex-direction-row is-align-content-center margin-right-80">
                <div class="author-img">
                  <img src="img/marina-doe.png" alt="marina doe">
                </div>
                <div class="author-detail">
                  <p class="text-md">
                    Author
                  </p>
                  <p class="text-xl is-wght-700">
                    Marina Doe
                  </p>
                </div>
  
              </div>
            </article>
          </div>
        </div>
        <div class="columns is-mobile is-multiline is-align-items-flex-start">
          <div class="column is-full-mobile is-one-third-desktop is-one-third-widescreen is-one-third-fullhd">
            <article class="tile transparent-invert-black is-flex-direction-column">
              <img class="m" src="img/performance-branding.png" alt="" srcset="">
              <div class="is-flex is-flex-direction-row is-justify-content-space-between">
                  <div class="category-tags">
                    <a href="#" class="custom tag is-rounded is-border-less is-transparent text-sm">Marketing</a>
                    <a href="#" class="custom tag is-rounded is-border-less is-transparent text-sm">Performance</a>
                  </div>
            </div>
              <div class="content">
               <h6 class="customized">Google Ads to Reddit: How We Tested 7 Different Acquisition Channels to Get Better Performance</h6>
               <p class="text-md">Phasellus at iaculis nisl. Vivamus eleifend purus quis elit suscipit dictum. Cras vitae sapien sed risus molestie lobortis. Mauris fermentum vulputate interdum. Quisque et turpis ullamcorper leo tristique mollis. Duis ut consequat justo, in mollis ligula.</p>
              </div>
              <div class="b-author is-flex-direction-row is-align-content-center margin-right-80">
                <div class="author-img">
                  <img src="img/marina-doe.png" alt="marina doe">
                </div>
                <div class="author-detail">
                  <p class="text-md">
                    Author
                  </p>
                  <p class="text-xl is-wght-700">
                    Marina Doe
                  </p>
                </div>
  
              </div>
            </article>
          </div>
          <div class="column is-full-mobile is-one-third-desktop is-one-third-widescreen is-one-third-fullhd">
            <article class="tile transparent-invert-black is-flex-direction-column">
              <img src="img/marketing-strategy.png" alt="" srcset="">
              <div class="is-flex is-flex-direction-row is-justify-content-space-between">
                  <div class="category-tags">
                    <a href="#" class="custom tag is-rounded is-border-less is-transparent text-sm">Marketing</a>
                    <a href="#" class="custom tag is-rounded is-border-less is-transparent text-sm">Performance</a>
                  </div>
            </div>
              <div class="content">
               <h6 class="customized">Klarna’s Marketing Strategy: The Unique Growth Story Behind The Brand</h6>
               <p class="text-md">Klarna's marketing strategy has transformed the online shopping experience. See how this unicorn leveraged performance branding to grow exponentially.</p>
              </div>
              <div class="b-author is-flex-direction-row is-align-content-center margin-right-80">
                <div class="author-img">
                  <img src="img/marina-doe.png" alt="marina doe">
                </div>
                <div class="author-detail">
                  <p class="text-md">
                    Author
                  </p>
                  <p class="text-xl is-wght-700">
                    Marina Doe
                  </p>
                </div>
  
              </div>
            </article>
          </div>
          <div class="column is-full-mobile is-one-third-desktop is-one-third-widescreen is-one-third-fullhd">
            <article class="tile transparent-invert-black is-flex-direction-column">
              <img src="img/data-science.png" alt="" srcset="">
              <div class="is-flex is-flex-direction-row is-justify-content-space-between">
                  <div class="category-tags">
                    <a href="#" class="custom tag is-rounded is-border-less is-transparent text-sm">Marketing</a>
                    <a href="#" class="custom tag is-rounded is-border-less is-transparent text-sm">Performance</a>
                  </div>
            </div>
              <div class="content">
               <h6 class="customized">Data Science in Marketing: A Comprehensive Guide (With Examples)</h6>
               <p class="text-md">Learn how data science methods like machine learning, clustering, and regression have moved marketing from a creative domain to a scientific one.</p>
              </div>
              <div class="b-author is-flex-direction-row is-align-content-center margin-right-80">
                <div class="author-img">
                  <img src="img/marina-doe.png" alt="marina doe">
                </div>
                <div class="author-detail">
                  <p class="text-md">
                    Author
                  </p>
                  <p class="text-xl is-wght-700">
                    Marina Doe
                  </p>
                </div>
  
              </div>
            </article>
          </div>
          <div class="column is-full-mobile is-one-third-desktop is-one-third-widescreen is-one-third-fullhd">
            <article class="tile transparent-invert-black is-flex-direction-column">
              <img src="img/performance-branding.png" alt="" srcset="">
              <div class="is-flex is-flex-direction-row is-justify-content-space-between">
                  <div class="category-tags">
                    <a href="#" class="custom tag is-rounded is-border-less is-transparent text-sm">Marketing</a>
                    <a href="#" class="custom tag is-rounded is-border-less is-transparent text-sm">Performance</a>
                  </div>
            </div>
              <div class="content">
               <h6 class="customized">Performance Branding: A Paradigm Shift in Marketing Strategies</h6>
               <p class="text-md">Phasellus at iaculis nisl. Vivamus eleifend purus quis elit suscipit dictum. Cras vitae sapien sed risus molestie lobortis. Mauris fermentum vulputate interdum. Quisque et turpis ullamcorper leo tristique mollis. Duis ut consequat justo, in mollis ligula.</p>
              </div>
              <div class="b-author is-flex-direction-row is-align-content-center margin-right-80">
                <div class="author-img">
                  <img src="img/marina-doe.png" alt="marina doe">
                </div>
                <div class="author-detail">
                  <p class="text-md">
                    Author
                  </p>
                  <p class="text-xl is-wght-700">
                    Marina Doe
                  </p>
                </div>
  
              </div>
            </article>
          </div>
          <div class="column is-full-mobile is-one-third-desktop is-one-third-widescreen is-one-third-fullhd">
            <article class="tile transparent-invert-black is-flex-direction-column">
              <img src="img/marketing-strategy.png" alt="" srcset="">
              <div class="is-flex is-flex-direction-row is-justify-content-space-between">
                  <div class="category-tags">
                    <a href="#" class="custom tag is-rounded is-border-less is-transparent text-sm">Marketing</a>
                    <a href="#" class="custom tag is-rounded is-border-less is-transparent text-sm">Performance</a>
                  </div>
            </div>
              <div class="content">
               <h6 class="customized">Klarna’s Marketing Strategy: The Unique Growth Story Behind The Brand</h6>
               <p class="text-md">Klarna's marketing strategy has transformed the online shopping experience. See how this unicorn leveraged performance branding to grow exponentially.</p>
              </div>
              <div class="b-author is-flex-direction-row is-align-content-center margin-right-80">
                <div class="author-img">
                  <img src="img/marina-doe.png" alt="marina doe">
                </div>
                <div class="author-detail">
                  <p class="text-md">
                    Author
                  </p>
                  <p class="text-xl is-wght-700">
                    Marina Doe
                  </p>
                </div>
  
              </div>
            </article>
          </div>
          <div class="column is-full-mobile is-one-third-desktop is-one-third-widescreen is-one-third-fullhd">
            <article class="tile transparent-invert-black is-flex-direction-column">
              <img src="img/data-science.png" alt="" srcset="">
              <div class="is-flex is-flex-direction-row is-justify-content-space-between">
                  <div class="category-tags">
                    <a href="#" class="custom tag is-rounded is-border-less is-transparent text-sm">Marketing</a>
                    <a href="#" class="custom tag is-rounded is-border-less is-transparent text-sm">Performance</a>
                  </div>
            </div>
              <div class="content">
               <h6 class="customized">Data Science in Marketing: A Comprehensive Guide (With Examples)</h6>
               <p class="text-md">Learn how data science methods like machine learning, clustering, and regression have moved marketing from a creative domain to a scientific one.</p>
              </div>
              <div class="b-author is-flex-direction-row is-align-content-center margin-right-80">
                <div class="author-img">
                  <img src="img/marina-doe.png" alt="marina doe">
                </div>
                <div class="author-detail">
                  <p class="text-md">
                    Author
                  </p>
                  <p class="text-xl is-wght-700">
                    Marina Doe
                  </p>
                </div>
  
              </div>
            </article>
          </div>
          <a href="#" class="button button-article gray2">Read the article <img src="img/right-arrow.svg" alt=""></a>
        </div>
      </div>
    </section>