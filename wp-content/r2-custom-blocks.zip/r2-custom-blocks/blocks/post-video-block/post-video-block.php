<?php

/**
 * Post Video Block Template.
 *
 * @param   array $block The block settings and attributes.
 * @param   string $content The block inner HTML (empty).
 * @param   bool $is_preview True during AJAX preview.
 * @param   (int|string) $post_id The post ID this block is saved to.
 */

// Create id attribute allowing for custom "anchor" value.
?>
<section class="fourth-one">
      <div class="container is-fullhd">
        <h3 class="customized-title">Take a video bite</h3>
        <div class="video-slides">
          <div class="video-slide">
            <div class="is-flex is-flex-direction-row is-mobile direction-column is-justify-content-space-evenly is-align-items-center">
              <div class="column-1-2">
                <img src="img/video-slide-1.png" alt="first video" srcset="">
              </div>
              <div class="column-2-2">
                <a href="#" class="custom tag red is-rounded is-transparent is-border-red text-sm">Marketing</a>
                <a href="#" class="custom tag red is-rounded is-transparent is-border-red text-sm">Vidoes</a>
                <h3 class="is-wght-700">Neuromarketing:<br> Hacking Into </br>Consumers’ Minds</h3>
                <div class="is-flex is-flex-direction-row">
                  <div class="b-author is-flex-direction-row is-align-content-center margin-right-80">
                    <div class="author-img">
                      <img src="img/marina-doe.png" alt="marina doe">
                    </div>
                    <div class="author-detail">
                      <p class="text-md">
                        Author
                      </p>
                      <p class="text-xl is-wght-700">
                        Marina Doe
                      </p>
                    </div>
      
                  </div>
                  </div>
              </div>
            </div>
          </div>
          <div class="video-slide">
            <div class="is-flex is-flex-direction-row is-mobile direction-column is-justify-content-space-evenly is-align-items-center">
              <div class="column-1-2">
                <img src="img/video-slide-1.png" alt="first video" srcset="">
              </div>
              <div class="column-2-2">
                <a href="#" class="custom tag red is-rounded is-transparent is-border-red text-sm">Marketing</a>
                <a href="#" class="custom tag red is-rounded is-transparent is-border-red text-sm">Vidoes</a>
                <h3 class="is-wght-700">Neuromarketing:<br> Hacking Into </br>Consumers’ Minds</h3>
                <div class="is-flex is-flex-direction-row">
                  <div class="b-author is-flex-direction-row is-align-content-center margin-right-80">
                    <div class="author-img">
                      <img src="img/marina-doe.png" alt="marina doe">
                    </div>
                    <div class="author-detail">
                      <p class="text-md">
                        Author
                      </p>
                      <p class="text-xl is-wght-700">
                        Marina Doe
                      </p>
                    </div>
      
                  </div>
                  </div>
              </div>
            </div>
          </div>
  
        </div>
  </div>
    </section>