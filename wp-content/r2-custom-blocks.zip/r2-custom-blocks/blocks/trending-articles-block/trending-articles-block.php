<?php

/**
 * Trending Articles Block Template.
 *
 * @param   array $block The block settings and attributes.
 * @param   string $content The block inner HTML (empty).
 * @param   bool $is_preview True during AJAX preview.
 * @param   (int|string) $post_id The post ID this block is saved to.
 */

// Create id attribute allowing for custom "anchor" value.
?>
 <section class="third-one">
      <div class="container is-fullhd">
        <div class="columns is-mobile">
          <div class="column">
            <h3 class="customized-title">Trending Articles</h3>
            <div class="tile is-ancestor">
              <div class="tile is-parent is-6">
                <article class="tile red-invert-white is-flex-direction-column">
                  <div class="is-flex is-flex-direction-row is-justify-content-space-between">
                      <div class="category-tags">
                        <a href="#" class="custom tag is-rounded is-transparent is-border-red text-sm">Marketing</a>
                        <a href="#" class="custom tag is-rounded is-transparent is-border-red text-sm">Performance</a>
                      </div>
                      <div class="trending-tag is-flex">
                        <a href="#" class="custom tag is-rounded is-transparent is-border-red text-sm">Marketing</a>
                      </div>
                </div>
                  <div class="content">
                   <h4>Google Ads to Reddit: How We Tested 7 Different Acquisition Channels to Get Better Performance</h4>
                   <p>As the worlds of branding and performance marketing overlap, performance branding emerges as the answer to a more efficient marketing strategy.</p>
                  </div>
                  <div class="b-author is-flex-direction-row is-align-content-center margin-right-80">
                    <div class="author-img">
                      <img src="img/marina-doe.png" alt="marina doe">
                    </div>
                    <div class="author-detail">
                      <p class="text-md">
                        Author
                      </p>
                      <p class="text-xl is-wght-700">
                        Marina Doe
                      </p>
                    </div>
      
                  </div>
                </article>
              </div>
              <div class="tile is-vertical is-3">
                <div class="tile">
                  <div class="tile is-parent is-vertical">
                    <article class="tile black-invert-white is-flex-direction-column margin-bottom-25">
                      <div class="is-flex is-flex-direction-row is-justify-content-space-between">
                          <div class="category-tags">
                            <a href="#" class="custom tag is-rounded is-transparent is-border-red text-sm">Marketing</a>
                          </div>
                    </div>
                      <div class="content">
                       <h4 class="text-xl">Klarna’s Marketing Strategy: The Unique Growth Story Behind The Brand</h4>
                      </div>
                      <div class="b-author is-flex-direction-row is-align-content-center">
                        <div class="author-img">
                          <img src="img/marina-doe.png" alt="marina doe">
                        </div>
                        <div class="author-detail">
                          <p class="text-md">
                            Author
                          </p>
                          <p class="text-xl is-wght-700">
                            Marina Doe
                          </p>
                        </div>
          
                      </div>
                    </article>
                    <article class="tile black-invert-white is-flex-direction-column">
                      <div class="is-flex is-flex-direction-row is-justify-content-space-between">
                          <div class="category-tags">
                            <a href="#" class="custom tag is-rounded is-transparent is-border-red text-sm">Marketing</a>
                          </div>
                    </div>
                      <div class="content">
                       <h4 class="text-xl">Klarna’s Marketing Strategy: The Unique Growth Story Behind The Brand</h4>
                      </div>
                      <div class="b-author is-flex-direction-row is-align-content-center">
                        <div class="author-img">
                          <img src="img/marina-doe.png" alt="marina doe">
                        </div>
                        <div class="author-detail">
                          <p class="text-md">
                            Author
                          </p>
                          <p class="text-xl is-wght-700">
                            Marina Doe
                          </p>
                        </div>
          
                      </div>
                    </article>
                  </div>
                </div>
              </div>
              <div class="tile is-vertical is-3">
                <div class="tile">
                  <div class="tile is-parent is-vertical">
                    <article class="tile black-invert-white is-flex-direction-column margin-bottom-25">
                      <div class="is-flex is-flex-direction-row is-justify-content-space-between">
                          <div class="category-tags">
                            <a href="#" class="custom tag is-rounded is-transparent is-border-red text-sm">Marketing</a>
                            <a href="#" class="custom tag is-rounded is-transparent is-border-red text-sm">Data</a>
                            <a href="#" class="custom tag is-rounded is-transparent is-border-red text-sm">...</a>
                          </div>
                    </div>
                      <div class="content">
                       <h4 class="text-xl">Klarna’s Marketing Strategy: The Unique Growth Story Behind The Brand</h4>
                      </div>
                      <div class="b-author is-flex-direction-row is-align-content-center">
                        <div class="author-img">
                          <img src="img/marina-doe.png" alt="marina doe">
                        </div>
                        <div class="author-detail">
                          <p class="text-md">
                            Author
                          </p>
                          <p class="text-xl is-wght-700">
                            Marina Doe
                          </p>
                        </div>
          
                      </div>
                    </article>
                    <article class="tile red-invert-white is-flex-direction-column is-justify-content-center">
                        <div class="category-tags customized">
                          <a href="#" class="custom tag is-rounded is-transparent is-border-red text-sm">...</a>
                          <a href="#" class="text-lg link">More Featured Articles</a>
                        </div>
                    </article>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>